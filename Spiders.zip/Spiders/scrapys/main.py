#coding=utf8
from scrapy import cmdline
import os
#cmdline.execute("scrapy crawl lianjia".split())

filename = os.system(ls -lt /home/cubie/Desktop/Spiders/scrapys/scrapys/results/  | grep jinan | head -n 1 |awk '{print $9}')

os.system("echo "test1" |mail -s "test1" -a /home/cubie/Desktop/Spiders/scrapys/scrapys/results/filename  1039020580@qq.com")  # 运行环球网的爬虫   http://m.blog.csdn.net/Firewall5788/article/details/74910012
