# Spiders
爬虫练习，详细信息参考各个目录下的readme.md文件


- 链家楼盘信息爬取

    >scrapys-->spiders.lianjia_spider.py

- 谷歌翻译爬取

    >translates-->goole_trans.py
    
- 百度翻译爬取
    >translates-->baidu_trans.py
    
  
